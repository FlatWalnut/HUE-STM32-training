//1��������શ�ʱ����һ�����Ե����ĵ�����
//2�����������У������ǰ��Сʱ�����ӡ���
//3�� ���þ�����̣�������
//4�������������ʾ��������������ܲ������ϸ���
//
#include "stm32f10x.h"
#include "time.h"
void display(void);
int keyread(void);
u8 disbuf[8]={0};
u16 delayms;


void 	GPIOKEYLED_Configuration(void)      //������LED������ܡ��������˿ڳ�ʼ��
  {
	GPIO_InitTypeDef   GPIO_InitStructure;                      
               
			 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);                         //��������
		
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15 ;                 //����ܶ���
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | 
	                               GPIO_Pin_8 | GPIO_Pin_9 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8 | GPIO_Pin_11 | 
	                               GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5 ;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4 ;
  GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	
		
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0|GPIO_Pin_1 |GPIO_Pin_10|GPIO_Pin_11|
                               	GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6|GPIO_Pin_8|GPIO_Pin_7|GPIO_Pin_9 ;                 //����ܶ���
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1 | 
	                               GPIO_Pin_13 | GPIO_Pin_2 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_2 ;                 //����ܶ���
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOD, &GPIO_InitStructure); 
	
	}


//����ϵͳʱ��,ʹ�ܸ�����ʱ��
void RCC_Configuration(void)
{   
	SystemInit();	  //ϵͳʱ�ӳ�ʼ��
	RCC_APB2PeriphClockCmd(
          	RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB |
           	RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD |   //���˿ڸ�ʱ�� 
	          RCC_APB2Periph_GPIOE, ENABLE );
}

//***************************************************************************************
void SYStick_config()
{
   SysTick_Config(SystemCoreClock /1000);    //����Ϊ1����
}             

//1�������ж�
//2���ж�����Ϊ1����,��ֵ��Ϊ:72000
//   �ж�����Ϊ2����,2MS,��ֵ��Ϊ��SystemFrequency /1000*2
//3���������ȼ�Ϊ"-1",���쳣�������ȼ���͵�.
//4����������     
//��������

//***************************************************************************************

void Init_All_Periph(void)
{   
	RCC_Configuration();	
	GPIOKEYLED_Configuration();     //����/LED��ʼ��
	SYStick_config();
}

void delay(u16 ms)
{
	delayms=ms;
	while (delayms>0)
	{
	;
	}
}
//*******************������********************************************
int main(void)
  {  
	
	u8 led=0;	
	 Init_All_Periph();    //��ʼ������Ӳ����ʼ������
	 GPIO_SetBits(GPIOC,GPIO_Pin_2);  //8��IO�ڣ�ȫ�ø�
	 GPIO_SetBits(GPIOC,GPIO_Pin_1);
   GPIO_SetBits(GPIOC,GPIO_Pin_0);
	 GPIO_SetBits(GPIOC,GPIO_Pin_13);   //����������
		
	 GPIO_SetBits(GPIOB,GPIO_Pin_9);
	 GPIO_SetBits(GPIOB,GPIO_Pin_8);
	 GPIO_SetBits(GPIOB,GPIO_Pin_7);
	 GPIO_SetBits(GPIOB,GPIO_Pin_6);  //�ɾ�������
	
 
	 while(1)
    	{
				delay(1000);
				led++;
				
				if (led>7) led=0;
				 switch (led){
				case 0:
				  GPIO_SetBits(GPIOB,GPIO_Pin_6);
				  GPIO_ResetBits(GPIOC,GPIO_Pin_2);
				  break;
				case 1:
				   GPIO_SetBits(GPIOC,GPIO_Pin_2);
				   GPIO_ResetBits(GPIOC,GPIO_Pin_1);
				   break;
				case 2:
				   GPIO_SetBits(GPIOC,GPIO_Pin_1);
		       GPIO_ResetBits(GPIOC,GPIO_Pin_0);
				   break;	
				case 3:
				   GPIO_SetBits(GPIOC,GPIO_Pin_0);
				   GPIO_ResetBits(GPIOC,GPIO_Pin_13);
				   break;	
				case 4:	
				   GPIO_SetBits(GPIOC,GPIO_Pin_13);
				   GPIO_ResetBits(GPIOB,GPIO_Pin_9);		
				   break;
				case 5:
				   GPIO_SetBits(GPIOB,GPIO_Pin_9);
				   GPIO_ResetBits(GPIOB,GPIO_Pin_8);
				   break;
				case 6:
				   GPIO_SetBits(GPIOB,GPIO_Pin_8);
				   GPIO_ResetBits(GPIOB,GPIO_Pin_7);
				   break;	
				case 7:
				   GPIO_SetBits(GPIOB,GPIO_Pin_7);
				   GPIO_ResetBits(GPIOB,GPIO_Pin_6);
				   break;	
			}

				
      }
			//while
  }  
	//main
        
//����ж�	
//�쳣����������**************************************************************************
//*****************************************************************************************

void update(u32 totalsecond)
{
	   u8 second,minute,hour;
	
		 second=totalsecond%60;
		 minute=totalsecond/60%60;
		 hour=totalsecond/3600%24;

		 disbuf[0]=hour / 10;
		 disbuf[1]=hour % 10;
     disbuf[2]= 20;	
		 disbuf[3]=minute/10;
		 disbuf[4]=minute%10;
     disbuf[5]= 20;	
		 disbuf[6]=second/10;
		 disbuf[7]=second%10;
}
		
void SysTick_Handler(void)        ///1ms�Ķ�ʱ�ж�
{		
	static u16 count=0;
	static u32 totalsecond=0;
	static u8 key,key2;
	
  if(delayms>0)
		delayms--;
	
	
	if (++count==1000)
	 {
	   count=0;
		 totalsecond++;
	   update(totalsecond);
	 }
	
  key2=key;
	key=keyread();
	if (key==1 && key2==0) 
		{
			totalsecond+=3600;
			update(totalsecond);
		}
	
	if (key==2 && key2==0) 
	  {
			totalsecond+=60;
		  update(totalsecond);
		}
	
	if (key==3 && key2==0)
		{ 
			totalsecond+=1;
			update(totalsecond);
		}
	

	if (key==4 && key2==0 && totalsecond>3600) 
		{
			totalsecond-=3600;
			update(totalsecond);
		}
	
		
	display();                           //��ʾ
}                                      

//**************************************************************************************************
//**************************************************************************************************

//��̬��ʾ����
void display(void)
{
   u8    dismode[22]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X6F,
											0XBF,0X86,0XDB,0XCF,0XE6,0XED,0XFD,0X87,0XFF,0XEF,0x40,0x00};
	//��ģ�У�������10�����֣�A~F��������ĸ���Լ�һЩ�������š�
  static char  count;
	if(++count==8)  count=0;
 
  GPIO_ResetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14 );
  GPIO_ResetBits(GPIOC,GPIO_Pin_5);
											
	GPIO_WriteBit(GPIOA,GPIO_Pin_12,(BitAction)(dismode[disbuf[count]]&0x01));	  //�Ͷ���
	GPIO_WriteBit(GPIOA,GPIO_Pin_11,(BitAction)(dismode[disbuf[count]]&0x02));	 
	GPIO_WriteBit(GPIOA,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x04));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_9, (BitAction)(dismode[disbuf[count]]&0x08));
	GPIO_WriteBit(GPIOC,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x10));
	GPIO_WriteBit(GPIOC,GPIO_Pin_7, (BitAction)(dismode[disbuf[count]]&0x20));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_6, (BitAction)(dismode[disbuf[count]]&0x40));		
	GPIO_WriteBit(GPIOB,GPIO_Pin_15,(BitAction)(dismode[disbuf[count]]&0x80));	
 
	GPIO_WriteBit(GPIOB,GPIO_Pin_14,(BitAction)((1<<count) & 0x01));	            //��λ��
	GPIO_WriteBit(GPIOB,GPIO_Pin_13,(BitAction)((1<<count) & 0x02));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,(BitAction)((1<<count) & 0x04));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)((1<<count) & 0x08));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)((1<<count) & 0x10));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_1, (BitAction)((1<<count) & 0x20));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_0, (BitAction)((1<<count) & 0x40));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_5, (BitAction)((1<<count) & 0x80));	
}
		
int keyread(void)  //������̳���
  {
	 GPIO_ResetBits(GPIOA,GPIO_Pin_5);
	 GPIO_SetBits(GPIOA,GPIO_Pin_4|GPIO_Pin_3);	
	 if( !GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)) return 1;	
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)) return 4;
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)) return 7;
	
	 GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	 GPIO_SetBits(GPIOA,GPIO_Pin_5|GPIO_Pin_3);	
	 if( !GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)) return 2;	
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)) return 5;
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)) return 8;	
		
	 GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	 GPIO_SetBits(GPIOA,GPIO_Pin_5|GPIO_Pin_4);	
	 if( !GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)) return 3;	
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)) return 6;
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)) return 9;	

   return 0;		
		
	}
		

	
	

	
		
		
		