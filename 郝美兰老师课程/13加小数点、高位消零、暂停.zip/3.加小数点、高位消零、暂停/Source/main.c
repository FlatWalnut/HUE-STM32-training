//1���޸�����жϳ�ֵ��ʹ��Ϊ�����ж�����
//2������ʾ����С���� ��0.1s
//3����ȥǰ���0
//4�������ͣһ�¡�

#include <stm32f10x.h>

int   keyread(void);
void  display(void);
u8    disbuf[8]={20,20,20,20,20,20,20,0};
u8    run=0;

void 	GPIOKEYLED_Configuration(void)      //������LED������ܡ��������˿ڳ�ʼ��
  {
	GPIO_InitTypeDef   GPIO_InitStructure;                      
               
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);	 
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
		
		
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);                         //��������
		
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15 ;                 //����ܶ���
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | 
	                               GPIO_Pin_8 | GPIO_Pin_9 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8 | GPIO_Pin_11 | 
	                               GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5 ;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
		
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0|GPIO_Pin_1 |GPIO_Pin_10|GPIO_Pin_11|
                               	GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4 ;
  GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	}

//����ϵͳʱ��,ʹ�ܸ�����ʱ��
void RCC_Configuration(void)
{   
	SystemInit();	  //ϵͳʱ�ӳ�ʼ��  //72000000
	RCC_APB2PeriphClockCmd(
          	RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB |
           	RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD,    //���˿ڸ�ʱ�� 
	          ENABLE );
}



//***************************************************************************************

void Init_All_Periph(void)
{   
	RCC_Configuration();	
	GPIOKEYLED_Configuration();     //����/LED��ʼ��
  
  SysTick_Config(SystemCoreClock /1000 ); //����Ϊ1���� //72000
	//����SysTick��װֵ��ʱ��Դ��ʹ�ܵδ�ʱ��

//�����룬����ͳ˼�

}



//*******************������********************************************
int main(void)
  {  
  u8    key=1;
	u8    key2=1;	
		
	Init_All_Periph();    //��ʼ���꣬�δ�ʱ��������������while��1����û��ʼ�ܣ���ʱ�����Ѿ�������

	GPIO_SetBits(GPIOC,GPIO_Pin_0 |GPIO_Pin_1 |GPIO_Pin_2|GPIO_Pin_13);
	GPIO_SetBits(GPIOB,GPIO_Pin_6 |GPIO_Pin_7 |GPIO_Pin_8|GPIO_Pin_9);
		
 
	 while(1)
	 {
    key2=key; 
    key = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2);
    if (key==1 && key2!=1)    //  ��ѯ��ʵ�ְ���PA2��ʱ��Ŀ���   
	  run=!run;
  
     }//while
  }   //main
        
//����ж�	
//�쳣����������**************************************************************************
//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************	
//      SysTick_Handler
 //    SysTick_Handler
void SysTick_Handler(void)    ///1ms�Ķ�ʱ�ж�
{
	static   u16    count=0;
  static   u32    second=0;     
	if (++count==100)  //ÿ100ms,second��1�Σ���secondÿ�μ�0.1s
    {
			count=0;
		  {
			
				if (run==1)
				second++;

			disbuf[7]=second%10;
			disbuf[6]=second/10%10+10;   //+10�ǰѶ�ӦС������ʾ����Ϊ���һλ�������ʾ�ĵ�λ��0.1s
	    
				if (second>10000000)
        disbuf[0]=second/10000000%10;
				else if (second>1000000)
        disbuf[1]=second/1000000%10;
				else if (second>100000)
        disbuf[2]=second/100000%10;
				else if (second>10000)
        disbuf[3]=second/10000%10;
				else if (second>1000)
        disbuf[4]=second/1000%10;
				else if (second>100)
				disbuf[5]=second/100%10;
   }
       }
    display();

   }
                                

//**************************************************************************************************
//**************************************************************************************************

//��̬��ʾ����
void display(void)
{
   u8  dismode[21]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X6F,
										0XBF,0X86,0XDB,0XCF,0XE6,0XED,0XFD,0X87,0XfF,0XeF,
	                  0x00};
	 
	 
//��ģ�У�������10�����֣�A~F��������ĸ���Լ�һЩ�������š�
//�м�10���Ǵ�С���㡣

  static char  count=0;
	if(++count==8)  count=0;
 
  GPIO_ResetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11
										|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14 );
  GPIO_ResetBits(GPIOC,GPIO_Pin_5);
										
	GPIO_WriteBit(GPIOA,GPIO_Pin_12,(BitAction)(dismode[disbuf[count]]&0x01));	  //�Ͷ���
	GPIO_WriteBit(GPIOA,GPIO_Pin_11,(BitAction)(dismode[disbuf[count]]&0x02));	 
	GPIO_WriteBit(GPIOA,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x04));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_9, (BitAction)(dismode[disbuf[count]]&0x08));
	GPIO_WriteBit(GPIOC,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x10));
	GPIO_WriteBit(GPIOC,GPIO_Pin_7, (BitAction)(dismode[disbuf[count]]&0x20));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_6, (BitAction)(dismode[disbuf[count]]&0x40));		
	GPIO_WriteBit(GPIOB,GPIO_Pin_15,(BitAction)(dismode[disbuf[count]]&0x80));	
 
	GPIO_WriteBit(GPIOB,GPIO_Pin_14,(BitAction)((1<<count) & 0x01));	            //��λ��
	GPIO_WriteBit(GPIOB,GPIO_Pin_13,(BitAction)((1<<count) & 0x02));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,(BitAction)((1<<count) & 0x04));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)((1<<count) & 0x08));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)((1<<count) & 0x10));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_1, (BitAction)((1<<count) & 0x20));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_0, (BitAction)((1<<count) & 0x40));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_5, (BitAction)((1<<count) & 0x80));	
}

		
		
		




		
		