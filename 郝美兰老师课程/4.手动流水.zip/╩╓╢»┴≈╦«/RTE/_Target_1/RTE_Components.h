
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'outint' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"

/* Keil::Device:StdPeriph Drivers:EXTI:3.5.0 */
#define RTE_DEVICE_STDPERIPH_EXTI
/* Keil::Device:StdPeriph Drivers:Framework:3.5.1 */
#define RTE_DEVICE_STDPERIPH_FRAMEWORK
/* Keil::Device:StdPeriph Drivers:GPIO:3.5.0 */
#define RTE_DEVICE_STDPERIPH_GPIO
/* Keil::Device:StdPeriph Drivers:RCC:3.5.0 */
#define RTE_DEVICE_STDPERIPH_RCC


#endif /* RTE_COMPONENTS_H */
