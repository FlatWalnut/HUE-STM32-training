// ��������ʵ�ּ�1������
//��������
// ��ˮ�ƵĴ����ƶ�
#include "stm32f10x.h"
void display(void);
u8 disbuf[8]={20,20,20,20,20,0,0,0};
u8 stop=1;


/*====================1.ʹ���ⲿʱ��====================*/

void RCC_Configuration(void)
{   
	SystemInit();	  //ϵͳʱ�ӳ�ʼ��
	RCC_APB2PeriphClockCmd(
          	RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB |
           	RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD, ENABLE );
}

          
/*====================2.����GPIO����====================*/

void 	GPIOKEYLED_Configuration(void)      //������LED������ܡ��������˿ڳ�ʼ��
  {
	GPIO_InitTypeDef   GPIO_InitStructure;                      
               
			 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1 |GPIO_Pin_2|GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;	
  GPIO_Init(GPIOC, &GPIO_InitStructure);                         //���
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;	
  GPIO_Init(GPIOB, &GPIO_InitStructure);  	
		
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);                         //��������
		
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15 ;                 //����ܶ���
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | 
	                               GPIO_Pin_8 | GPIO_Pin_9 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8 | GPIO_Pin_11 | 
	                               GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5 ;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
		
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0|GPIO_Pin_1 |GPIO_Pin_10|GPIO_Pin_11|
                               	GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	}



void Init_All_Periph(void)
{   
	RCC_Configuration();	
	GPIOKEYLED_Configuration();     //����/LED��ʼ��
	SysTick_Config(SystemCoreClock /1000);  //�ж�����1ms
}



//������ʱ 

void delay(u16  delaytime)
{
	int i,j;
  for (i=0;i<delaytime;i++)
	for(j=0;j<1000;j++)
	  ;
}


//*******************������********************************************
int main(void)
  {  
	
   u8    key;
	 u8    key2;
	 u8   led=0;		
		
	 Init_All_Periph();    //��ʼ������Ӳ����ʼ������
 
		
	 GPIO_SetBits(GPIOC,GPIO_Pin_2);  //8��IO�ڣ�ȫ�ø�
	 GPIO_SetBits(GPIOC,GPIO_Pin_1);
   GPIO_SetBits(GPIOC,GPIO_Pin_0);
	 GPIO_SetBits(GPIOC,GPIO_Pin_13);   //����������
		
	 GPIO_SetBits(GPIOB,GPIO_Pin_9);
	 GPIO_SetBits(GPIOB,GPIO_Pin_8);
	 GPIO_SetBits(GPIOB,GPIO_Pin_7);
	 GPIO_SetBits(GPIOB,GPIO_Pin_6);  //�ɾ�������
	 while(1)
    	{
			
			if (++led==8) led=0;	
			switch(led)
			{
				case 0:
			    GPIO_SetBits(GPIOB,GPIO_Pin_6);
			    GPIO_ResetBits(GPIOC,GPIO_Pin_2);
				  break;
			     //GPIO_ResetBits(GPIOD,GPIO_Pin_2);
				case 1:
       	  GPIO_SetBits(GPIOC,GPIO_Pin_2);
			    GPIO_ResetBits(GPIOC,GPIO_Pin_1);
				  break;
				case 2:
       		GPIO_SetBits(GPIOC,GPIO_Pin_1);
			    GPIO_ResetBits(GPIOC,GPIO_Pin_0);
				  break;
	
				case 3:
       		GPIO_SetBits(GPIOC,GPIO_Pin_0);
			    GPIO_ResetBits(GPIOC,GPIO_Pin_13);
					break;
				case 4:
       		GPIO_SetBits(GPIOC,GPIO_Pin_13);
			    GPIO_ResetBits(GPIOB,GPIO_Pin_9);
			    break;
				case 5:
       		GPIO_SetBits(GPIOB,GPIO_Pin_9);
			    GPIO_ResetBits(GPIOB,GPIO_Pin_8);
			    break;
				case 6:
       		GPIO_SetBits(GPIOB,GPIO_Pin_8);
			    GPIO_ResetBits(GPIOB,GPIO_Pin_7);
				  break;
				case 7:
       		GPIO_SetBits(GPIOB,GPIO_Pin_7);
			    GPIO_ResetBits(GPIOB,GPIO_Pin_6);
					break;
			}
			 delay(1000);   //������ʱ�������ʱ̫�̣���delay(10); �������ֲ���������ledͬʱ�����޷�������ˮ

     }//while
  }   //main
        
//����ж�	
//�쳣����������**************************************************************************
//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************	
void SysTick_Handler(void)    ///1ms�Ķ�ʱ�ж�
{
	static u8   key1[5];
	static u8   key=0;
	static u8   key2;
	static u32  counter=0;
//**************************************************************************************************
	key1[4]=key1[3];
	key1[3]=key1[2];
	key1[2]=key1[1];
	key1[1]=key1[0];
	key1[0]=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2); 

	if (key1[0]==key1[1] && key1[0]==key1[2] &&key1[0]==key1[3] &&key1[0]==key1[4] )  //��������
	 {
	   key2=key;
	   key=key1[0];
	 }
	 
//	key2=key;
//	key=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2);
	if(key==0 && key2!=0)     //��ѯ��ʵ�ֿ��Ƽ���
	{  counter++; 	  

			disbuf[7]=counter%10;            //��λ
			disbuf[6]=counter/10%10;         //ʮλ
			disbuf[5]=counter/100%10;        //��λ
			disbuf[4]=20;       //ǧλ
			disbuf[3]=20;      //��λ
			disbuf[2]=20; 
			disbuf[1]=20;      
			disbuf[0]=20; 

	}
	
  display();                           //��ʾ
}                                      

//**************************************************************************************************
//**************************************************************************************************

//��̬��ʾ����
void display(void)
{
   u8    dismode[21]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X6F,
											0XBF,0X86,0XDB,0XCF,0XE6,0XED,0XFD,0X87,0XfF,0XeF,0x00};
	//��ģ�У�������10�����֣�A~F��������ĸ���Լ�һЩ�������š�
  static char  count=0;
	if(++count==8)  count=0;
 
  GPIO_ResetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14 );
  GPIO_ResetBits(GPIOC,GPIO_Pin_5);    //�����������ȫ�������ʱ��̣������޷�ʶ��
											
	GPIO_WriteBit(GPIOA,GPIO_Pin_12,(BitAction)(dismode[disbuf[count]]&0x01));	  //�Ͷ���
	GPIO_WriteBit(GPIOA,GPIO_Pin_11,(BitAction)(dismode[disbuf[count]]&0x02));	 
	GPIO_WriteBit(GPIOA,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x04));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_9, (BitAction)(dismode[disbuf[count]]&0x08));
	GPIO_WriteBit(GPIOC,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x10));
	GPIO_WriteBit(GPIOC,GPIO_Pin_7, (BitAction)(dismode[disbuf[count]]&0x20));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_6, (BitAction)(dismode[disbuf[count]]&0x40));		
	GPIO_WriteBit(GPIOB,GPIO_Pin_15,(BitAction)(dismode[disbuf[count]]&0x80));	
 
	GPIO_WriteBit(GPIOB,GPIO_Pin_14,(BitAction)((1<<count) & 0x01));	            //��λ��
	GPIO_WriteBit(GPIOB,GPIO_Pin_13,(BitAction)((1<<count) & 0x02));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,(BitAction)((1<<count) & 0x04));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)((1<<count) & 0x08));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)((1<<count) & 0x10));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_1, (BitAction)((1<<count) & 0x20));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_0, (BitAction)((1<<count) & 0x40));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_5, (BitAction)((1<<count) & 0x80));	
}
		
		


	
		
		
		