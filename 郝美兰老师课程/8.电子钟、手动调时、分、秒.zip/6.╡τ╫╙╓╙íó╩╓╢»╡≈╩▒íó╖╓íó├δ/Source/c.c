
u8 disbuf[8];   //定义数码管动态显示数据缓冲区。
.....................
SysTick_Config(SystemCoreClock /1000 );    
.....................
void SysTick_Handler(void)    
{
  static   u8   count=0;
  static   u32   second=0;
  if(++count==100 )	  
    {
  	count=0;
	second++; 
	disbuf[7]=second%10;          
	disbuf[6]=second/10%10;        
	disbuf[5]=second/100%10;       
	disbuf[4]=second/1000%10;      
	disbuf[3]=second/10000%10;     
	disbuf[2]=second/100000%10; 
	disbuf[1]=second/1000000%10;      
	disbuf[0]=second/10000000%10; 
    } 
  display(); //数码管动态显示程序，在数码管上显示disbuf中的数据         
} 
	

void TIM_Configuration(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;           
	TIM_OCInitTypeDef        TIM_OCInitStructure;
	NVIC_InitTypeDef         NVIC_InitStructure;
	TIM_TimeBaseStructure.TIM_Prescaler = 7200-1;            
	TIM_TimeBaseStructure.TIM_Period = 65535;                
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;    
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM4, & TIM_TimeBaseStructure);
	TIM_Cmd(TIM4, ENABLE);                                    
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_Toggle;           
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable ;
	TIM_OCInitStructure.TIM_Pulse =5000;                          
	TIM_OC1Init(TIM4,&TIM_OCInitStructure);                  
	TIM_ITConfig(TIM4,TIM_IT_CC1,ENABLE); 

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	         
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;           
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	     
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	          
	NVIC_Init(&NVIC_InitStructure);	   
}
void TIM4_IRQHandler(void)   
{	
	if (TIM_GetITStatus(TIM4,TIM_IT_CC1)!=RESET)  
	{	
	TIM_ClearITPendingBit(TIM4, TIM_IT_CC1);     
    x=TIM_GetCapture1(TIM4)+5000;                
    TIM_SetCompare1(TIM4,x);                    
}

	
	
		