    //1���޸�����жϳ�ֵ��ʹ��Ϊ�����ж�����
//2�����󰴼�1��2��3�ֱ��Ӧʱ���������1
//3�����󰴼�4��5��6�ֱ��Ӧʱ���������1
//4�������ͣһ�¡�

#include <stm32f10x.h>

int   keyread(void);
void  display(void);
u8    disbuf[8]={0,0,21,0,0,21,0,0};
u8     run=0;
void 	GPIOKEYLED_Configuration(void)      //������LED������ܡ��������˿ڳ�ʼ��
  {
	GPIO_InitTypeDef   GPIO_InitStructure;                      
               
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1 |GPIO_Pin_2|GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;	
  GPIO_Init(GPIOC, &GPIO_InitStructure);                         //���
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;	
  GPIO_Init(GPIOB, &GPIO_InitStructure);  	

		
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);                         //��������
		
	
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15 ;                 //����ܶ���
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | 
	                               GPIO_Pin_8 | GPIO_Pin_9 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8 | GPIO_Pin_11 | 
	                               GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5 ;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOC, &GPIO_InitStructure); 
	
		
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0|GPIO_Pin_1 |GPIO_Pin_10|GPIO_Pin_11|
                               	GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;                 //λ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	            
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4 ;
  GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	             
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	}

//����ϵͳʱ��,ʹ�ܸ�����ʱ��
void RCC_Configuration(void)
{   
	SystemInit();	  //ϵͳʱ�ӳ�ʼ��  //72000000
	RCC_APB2PeriphClockCmd(
          	RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB |
           	RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD,    //���˿ڸ�ʱ�� 
	          ENABLE );
}



//***************************************************************************************

void Init_All_Periph(void)
{   
	RCC_Configuration();	
	GPIOKEYLED_Configuration();     //����/LED��ʼ��
  
  SysTick_Config(SystemCoreClock /1000 ); //����Ϊ1���� //72000

//�����룬����ͳ˼�

}



//*******************������********************************************
int main(void)
  {  
	
   u8    key;
	 u8    key2;	
		
	 Init_All_Periph();    //��ʼ������Ӳ����ʼ��������
 
			
	GPIO_SetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_13);  //8��IO�ڣ�ȫ�ø�
	GPIO_SetBits(GPIOB,GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9);
		

		while(1)
	 {
  
     }//while
  }   //main
        
//����ж�	
//�쳣����������**************************************************************************

void SysTick_Handler(void)    ///1ms�Ķ�ʱ�ж�
{	
  static    u8   key1[5];   //��̬���飬ϵͳ�ϵ��Զ�����
	static   u16   count=0;
  static   u32   secondtotal=0;
  static    u8   hour,minute,second;
  static    u8   key2=0,key=0;

	key1[4]=key1[3];
	key1[3]=key1[2];
	key1[2]=key1[1];
	key1[1]=key1[0];
  key1[0]=keyread();   //��������

	if (key1[0]==key1[1] && key1[0]==key1[2] &&key1[0]==key1[3] &&key1[0]==key1[4] )    //��������,�ȴ���ֱ����ƽ�ȶ���5�ε�ƽ��ͬ����ѯ��
	 {
	   key2=key;
	   key=key1[0];
	 }
 
   if (key!=0 && key2==0)
   switch (key)
    {
    case 1:
			secondtotal=secondtotal+3600;   //��Сʱ��1
			break;
    case 2:
			secondtotal=secondtotal+60;    //�����Ӽ�1
			break;
    case 3:
			secondtotal=secondtotal+1;     //�����1
			break;
    case 4:
			if (secondtotal>3600)      
				secondtotal=secondtotal-3600;   //��Сʱ��1
			break;
    case 5:
      if (secondtotal>60)
				secondtotal=secondtotal-60;     //�����Ӽ�1
			break;
    case 6:
      if (secondtotal>1)
				secondtotal=secondtotal-1;      //�����1
			break;

   }

  	if (++count==1000)   //1000ms=1s  
    {
			count=0;
			secondtotal+=1;   //��ʱ��1s
    }
    if(count==0 || key>0)   //ÿ���Զ�ˢ��+������������ˢ�£� ������ʱ����ʱ׼ȷ�����õ���ʱ�䷴Ӧ��
     {
      
			second=secondtotal%60;      //60����
      minute=secondtotal/60%60;
      hour=secondtotal/3600%24;    //Сʱ��24����
			 
			 
      disbuf[7]=second%10;         //��λ
      disbuf[6]=second/10;         //ʮλ  

      disbuf[4]=minute%10;
      disbuf[3]=minute/10;

      disbuf[1]=hour%10;
      disbuf[0]=hour/10;
      }
      display();
   }

                                  

//**************************************************************************************************
//**************************************************************************************************

//��̬��ʾ����
void display(void)
{
   u8  dismode[22]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X6F,
										0XBF,0X86,0XDB,0XCF,0XE6,0XED,0XFD,0X87,0XfF,0XeF,
	                  0x00,0x40};   //0x40�Ƕ̻���-
	 
	 
//��ģ�У�������10�����֣�A~F��������ĸ���Լ�һЩ�������š�
//�м�10���Ǵ�С���㡣

  static char  count=0;
	if(++count==8)  count=0;
 
  GPIO_ResetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11
										|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14 );
  GPIO_ResetBits(GPIOC,GPIO_Pin_5);    //����
										
	GPIO_WriteBit(GPIOA,GPIO_Pin_12,(BitAction)(dismode[disbuf[count]]&0x01));	  //�Ͷ���
	GPIO_WriteBit(GPIOA,GPIO_Pin_11,(BitAction)(dismode[disbuf[count]]&0x02));	 
	GPIO_WriteBit(GPIOA,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x04));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_9, (BitAction)(dismode[disbuf[count]]&0x08));
	GPIO_WriteBit(GPIOC,GPIO_Pin_8, (BitAction)(dismode[disbuf[count]]&0x10));
	GPIO_WriteBit(GPIOC,GPIO_Pin_7, (BitAction)(dismode[disbuf[count]]&0x20));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_6, (BitAction)(dismode[disbuf[count]]&0x40));		
	GPIO_WriteBit(GPIOB,GPIO_Pin_15,(BitAction)(dismode[disbuf[count]]&0x80));	
 
	GPIO_WriteBit(GPIOB,GPIO_Pin_14,(BitAction)((1<<count) & 0x01));	            //��λ��
	GPIO_WriteBit(GPIOB,GPIO_Pin_13,(BitAction)((1<<count) & 0x02));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,(BitAction)((1<<count) & 0x04));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_11,(BitAction)((1<<count) & 0x08));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_10,(BitAction)((1<<count) & 0x10));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_1, (BitAction)((1<<count) & 0x20));	
	GPIO_WriteBit(GPIOB,GPIO_Pin_0, (BitAction)((1<<count) & 0x40));	
	GPIO_WriteBit(GPIOC,GPIO_Pin_5, (BitAction)((1<<count) & 0x80));	
}


int keyread(void)  //������̳���
  {
	 GPIO_ResetBits(GPIOA,GPIO_Pin_5);
	 GPIO_SetBits(GPIOA,GPIO_Pin_4|GPIO_Pin_3);	
	 if( !GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)) return 1;	
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)) return 4;
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)) return 7;
	
	 GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	 GPIO_SetBits(GPIOA,GPIO_Pin_5|GPIO_Pin_3);	
	 if( !GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)) return 2;	
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)) return 5;
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)) return 8;	
		
	 GPIO_ResetBits(GPIOA,GPIO_Pin_3);
	 GPIO_SetBits(GPIOA,GPIO_Pin_5|GPIO_Pin_4);	
	 if( !GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)) return 3;	
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)) return 6;
	 else if( !GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)) return 9;	

   return 0;		
		
	}
		
		
		




		
		